##### Thomas Morris 
##### Assignment 2 README 
##### October 3, 2019

##### Question 1
This program is meant to allow the user to use push, pop, top and getMin() functions on a stack.
To get the minimum this the user must create a stack, the use push to function to put data into the stack.
Once there is data in the stack the getMin() function can be called to retrieve the smallest item in the stack
and print that item out in the console.

##### Question 2
This program will receive a string in the evalExp function that represents an expression and evaluations that expression using a stack.
The program will display the output of the expression in the console. 

##### Question 3
This program receives a string in the evalPost function that represents an expression in Postfix Notation.
The program will display the output of the expression in the console.