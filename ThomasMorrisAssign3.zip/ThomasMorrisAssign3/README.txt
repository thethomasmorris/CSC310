### Thomas Morris
### Assignment 3 README
### October 19, 2019

### Question 1
The purpose of this program is to create a circular deque that allows insertion and deletion from either the
front or rear. To run this program you must first create a new deque using the MyCircularDeque class of the size given during construction.
After creating a new deque you can then call each of the specified functions, such as insertLast(), to perform the 
desired action. 
 
### Question 2 
The purpose of this program is to merge two already sorted linked lists.
To run this program you must create two sorted LinkedList. Then you have to create a new LinkedList to hold
the newly merge sorted list. To perform the merge sort you must the pass the head of each list to the merge function.

### Question 3
The purpose of this program is to implement a queue using linked lists. To run this program you must create a linked
queue and then call the functions, such as enqueue(), to perform the desired action. This program supports search()
as well which allows you provide a key and see if that key is in the queue.